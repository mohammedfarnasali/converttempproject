package MiniProject;

// Importing necessary libraries and classes
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelectDobDropdown {

    public static void main(String[] args) throws InterruptedException, IOException {
        // Load the Excel file where input data is stored
        FileInputStream fis = new FileInputStream("C:\\Users\\2388951\\eclipse-workspace\\seleniumwebdriver\\src\\test\\java\\INPUTDATA\\input.xlsx");
        Workbook workbook = WorkbookFactory.create(fis);
        
        // Access the first sheet in the workbook
        Sheet sheet = workbook.getSheetAt(0);

        // Get data from the first row, starting from the second one
        Row row = sheet.getRow(1);
        String firstName = getCellValueAsString(row.getCell(0)); // Retrieve first name
        String lastName = getCellValueAsString(row.getCell(1)); // Retrieve last name
        String mobileNumber = getCellValueAsString(row.getCell(2)); // Retrieve mobile number
        String day = getCellValueAsString(row.getCell(3)); // Retrieve day for dropdown
        String month = getCellValueAsString(row.getCell(4)); // Retrieve month for dropdown
        String year = getCellValueAsString(row.getCell(5)); // Retrieve year for dropdown
        String gender = getCellValueAsString(row.getCell(6)); // Retrieve gender selection

        // Launch the browser and prepare WebDriver
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize(); // Maximize browser for better visibility

        try {
            // Go to Facebook's website
            driver.get("http://www.fb.com");
            System.out.println("Page Title: " + driver.getTitle()); // Print the title of the page

            // Click the "Create New Account" button to open the signup form
            WebElement ClickNewAccount = driver.findElement(By.xpath("//*[@role='button' and @data-testid='open-registration-form-button']"));
            ClickNewAccount.click();

            // Fill in the form fields with data retrieved from Excel
            WebElement EnterFName = driver.findElement(By.name("firstname"));
            EnterFName.sendKeys(firstName); // Enter First Name

            WebElement SurName = driver.findElement(By.name("lastname"));
            SurName.sendKeys(lastName); // Enter Last Name

            WebElement MobileNum = driver.findElement(By.name("reg_email__"));
            MobileNum.sendKeys(mobileNumber); // Enter Mobile Number

            // Select the day from the "Day" dropdown
            WebElement dayDropdown = driver.findElement(By.id("day"));
            Select dropdown = new Select(dayDropdown);
            dropdown.selectByVisibleText(day);

            // Select the month from the "Month" dropdown
            WebElement Mdropdown = driver.findElement(By.id("month"));
            Select monthdropdown = new Select(Mdropdown);
            monthdropdown.selectByIndex(3); // Example: Selecting April (index starts at 0)

            // Select the year from the "Year" dropdown
            WebElement Ydropdown = driver.findElement(By.id("year"));
            Select yeardropdown = new Select(Ydropdown);
            yeardropdown.selectByValue(year);

            // Select the gender based on the input
            WebElement Gender = driver.findElement(By.xpath("//*[@id='sex' and @value='" + gender + "']"));
            Gender.click();

            // Click the "Sign Up" button
            WebElement signin = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("websubmit")));
            signin.click();

            // Display error messages if any validation fails
            String errorXpath = "//div[@class='uiContextualLayerPositioner _572t uiLayer']/div/div/div";
            String iXpathMobile = "//div[@class='_5dbb _5634']/div/input[@name='reg_email__']/following::i[1]";
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(iXpathMobile)));
            WebElement iMobButton = driver.findElement(By.xpath(iXpathMobile));
            iMobButton.click(); // Click the mobile error icon
            WebElement numError = driver.findElement(By.xpath(errorXpath));
            System.out.println("Error Message displayed for Mobile number: " + numError.getText());

            String iXpathPass = "//div[@class='_5dbb _5634']/div/input[@name='reg_passwd__']/following::i[1]";
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(iXpathPass)));
            WebElement iPassButton = driver.findElement(By.xpath(iXpathPass));
            iPassButton.click(); // Click the password error icon
            WebElement passError = driver.findElement(By.xpath(errorXpath));
            System.out.println("Error Message displayed for Password: " + passError.getText());

        } catch (Exception e) {
            // Print any exception encountered
            e.printStackTrace();
        } finally {
            // Clean up resources to avoid memory leaks
            driver.quit(); // Close the browser
            workbook.close(); // Close the Excel workbook
            fis.close(); // Close the file input stream
        }
    }

    // Method to convert cell values to strings regardless of the cell's type
    public static String getCellValueAsString(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue(); // If cell contains text
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue()); // If cell contains numbers
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue()); // If cell contains true/false
            case FORMULA:
                return cell.getCellFormula(); // If cell contains a formula
            default:
                return ""; // Return empty for other types
        }
    }
}
